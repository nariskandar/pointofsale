<?php

namespace Box\Spout\Reader\Exception;

/**
 * Class XMLProcessingException
 *
 * @package Box\Spout\Reader\Exception
 */
class XMLProcessingException extends ReaderException
{
}
